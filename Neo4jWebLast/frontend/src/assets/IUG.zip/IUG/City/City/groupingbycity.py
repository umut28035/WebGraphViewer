from collections import defaultdict

# Verileri oku ve şehirlere göre grupla
city_data = defaultdict(list)
with open('veri.txt', 'r') as f:
    for line in f:
        parts = line.strip().split(':', 1)
        city = parts[0].replace('OSB', '').strip()
        ip_url = parts[1].strip().split(':')
        ip = ip_url[0].strip()
        url = ':'.join(ip_url[1:]).strip()
        city_data[city].append((ip, url))

# Her şehir için ayrı dosyalara yaz
for city, data in city_data.items():
    with open(f"{city}_veriler.txt", 'w') as f:
        f.write(f"{city}:\n")
        for ip, url in data:
            f.write(f"  {ip}:{url}\n")
